## KillStreak — combo counter z wizualnym feedbackiem
extends CanvasLayer

var _kill_count: int = 0
var _combo_timer: float = 0.0
const COMBO_WINDOW: float = 2.0  ## sekundy na kolejny kill
const MIN_STREAK: int = 3        ## minimum do wyświetlenia
var _active: bool = false  ## disabled during shop / between waves

var _label: Label
var _tween: Tween = null


func _ready() -> void:
	layer = 5
	_label = Label.new()
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	# Fixed anchored position — never moves
	_label.anchor_left = 0.5
	_label.anchor_right = 0.5
	_label.anchor_top = 0.0
	_label.anchor_bottom = 0.0
	_label.offset_left = -160
	_label.offset_right = 160
	_label.offset_top = 8
	_label.offset_bottom = 48
	_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_label.grow_vertical = Control.GROW_DIRECTION_END
	# Pivot at center so scale pulse doesn't shift position
	_label.pivot_offset = Vector2(160, 20)
	_label.add_theme_font_size_override("font_size", 16)
	_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.1))
	_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	_label.add_theme_constant_override("shadow_offset_x", 2)
	_label.add_theme_constant_override("shadow_offset_y", 2)
	_label.visible = false
	add_child(_label)
	EventBus.enemy_killed_at.connect(_on_enemy_killed)
	EventBus.wave_started.connect(_on_wave_started)
	EventBus.wave_cleared.connect(_on_wave_ended)
	EventBus.shop_opened.connect(_force_hide)


func _on_wave_started(_wave: int) -> void:
	_active = true
	_kill_count = 0
	_combo_timer = 0.0
	_force_hide()


func _on_wave_ended(_wave: int) -> void:
	_active = false
	_force_hide()


func _force_hide() -> void:
	_kill_count = 0
	_combo_timer = 0.0
	if _tween and _tween.is_valid():
		_tween.kill()
	_tween = null
	_label.visible = false
	_label.modulate = Color.WHITE


func _on_enemy_killed(_pos: Vector2) -> void:
	if not _active:
		return
	_kill_count += 1
	_combo_timer = COMBO_WINDOW
	if _kill_count > GameManager.max_streak:
		GameManager.max_streak = _kill_count
	if _kill_count >= MIN_STREAK:
		_show_streak()


func _show_streak() -> void:
	_label.text = "× %d KILL STREAK!" % _kill_count
	_label.visible = true
	_label.modulate = Color.WHITE
	# Pulse effect
	if _tween and _tween.is_valid():
		_tween.kill()
	_tween = create_tween()
	_label.scale = Vector2(1.3, 1.3)
	_tween.tween_property(_label, "scale", Vector2(1.0, 1.0), 0.15).set_ease(Tween.EASE_OUT)


func _process(delta: float) -> void:
	if _combo_timer > 0.0:
		_combo_timer -= delta
		if _combo_timer <= 0.0:
			_end_streak()


func _end_streak() -> void:
	if _kill_count >= MIN_STREAK and _label.visible:
		if _tween and _tween.is_valid():
			_tween.kill()
		_tween = create_tween()
		_tween.tween_property(_label, "modulate:a", 0.0, 0.4)
		_tween.tween_callback(func(): _label.visible = false)
	_kill_count = 0
