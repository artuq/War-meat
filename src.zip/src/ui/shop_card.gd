## ShopCard — karta przedmiotu w sklepie (Brotato-style)
class_name ShopCard
extends PanelContainer

signal purchased(card: ShopCard)
signal locked_toggled(card: ShopCard)
signal banished(card: ShopCard)
signal hovered(card: ShopCard)
signal unhovered(card: ShopCard)

enum CardType { WEAPON, PASSIVE, CONSUMABLE, RECRUIT }

var card_type: CardType = CardType.WEAPON
var card_data: Variant = null  # Dictionary (weapon/consumable) or PassiveItem
var weapon_tier: WeaponData.Tier = WeaponData.Tier.COMMON
var is_locked: bool = false
var is_owned: bool = false
var _border_color: Color = Color(0.3, 0.3, 0.3)

var _icon_rect: ColorRect
var _type_label: Label
var _desc_label: RichTextLabel
var _buy_button: Button
var _lock_button: Button
var _banish_button: Button


func _ready() -> void:
	custom_minimum_size = Vector2(80, 120)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_ui()
	_apply_style()


func _build_ui() -> void:
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 2)
	add_child(vbox)

	# Top row: icon + type
	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 4)
	vbox.add_child(top_row)

	_icon_rect = ColorRect.new()
	_icon_rect.custom_minimum_size = Vector2(16, 16)
	_icon_rect.color = Color.GRAY
	_icon_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_row.add_child(_icon_rect)

	_type_label = Label.new()
	_type_label.add_theme_font_size_override("font_size", 8)
	_type_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_type_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_row.add_child(_type_label)

	# Description (BBCode)
	_desc_label = RichTextLabel.new()
	_desc_label.bbcode_enabled = true
	_desc_label.fit_content = true
	_desc_label.scroll_active = false
	_desc_label.custom_minimum_size = Vector2(0, 24)
	_desc_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_desc_label.add_theme_font_size_override("normal_font_size", 8)
	_desc_label.add_theme_font_size_override("bold_font_size", 9)
	vbox.add_child(_desc_label)

	# Separator
	var sep := HSeparator.new()
	vbox.add_child(sep)

	# Bottom row: buy + lock + banish
	var bottom_row := HBoxContainer.new()
	bottom_row.add_theme_constant_override("separation", 2)
	vbox.add_child(bottom_row)

	_buy_button = Button.new()
	_buy_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_buy_button.custom_minimum_size = Vector2(0, 22)
	_buy_button.add_theme_font_size_override("font_size", 8)
	_buy_button.pressed.connect(_on_buy_pressed)
	bottom_row.add_child(_buy_button)

	_lock_button = Button.new()
	_lock_button.text = "🔓"
	_lock_button.custom_minimum_size = Vector2(22, 22)
	_lock_button.add_theme_font_size_override("font_size", 8)
	_lock_button.pressed.connect(_on_lock_pressed)
	bottom_row.add_child(_lock_button)

	_banish_button = Button.new()
	_banish_button.text = "✕"
	_banish_button.custom_minimum_size = Vector2(22, 22)
	_banish_button.add_theme_font_size_override("font_size", 8)
	_banish_button.pressed.connect(_on_banish_pressed)
	bottom_row.add_child(_banish_button)
	_banish_button.visible = false  # only for passives

	# Hover preview
	mouse_entered.connect(func(): hovered.emit(self))
	mouse_exited.connect(func(): unhovered.emit(self))


func _apply_style() -> void:
	var style: StyleBox
	var tex := load("res://assets/sprites/ui/Panel BG.svg") as Texture2D
	if tex:
		var style_tex := StyleBoxTexture.new()
		style_tex.texture = tex
		style_tex.texture_margin_left = 6
		style_tex.texture_margin_top = 6
		style_tex.texture_margin_right = 6
		style_tex.texture_margin_bottom = 6
		style_tex.content_margin_left = 4
		style_tex.content_margin_top = 4
		style_tex.content_margin_right = 4
		style_tex.content_margin_bottom = 4
		if is_locked:
			style_tex.modulate_color = Color(1.0, 0.85, 0.2)
		else:
			style_tex.modulate_color = Color.WHITE
		style = style_tex
	else:
		var style_flat := StyleBoxFlat.new()
		style_flat.bg_color = Color(0.12, 0.12, 0.14)
		style_flat.border_color = _border_color
		style_flat.set_border_width_all(1)
		style_flat.set_corner_radius_all(3)
		style_flat.set_content_margin_all(4)
		if is_locked:
			style_flat.border_color = Color(1.0, 0.85, 0.2)
			style_flat.border_width_top = 2
			style_flat.border_width_bottom = 2
			style_flat.border_width_left = 2
			style_flat.border_width_right = 2
		style = style_flat
	add_theme_stylebox_override("panel", style)


# ── Setup Methods ──

func setup_weapon(item: Dictionary, tier: WeaponData.Tier, owned: bool, gold: int, can_banish: bool = false) -> void:
	card_type = CardType.WEAPON
	card_data = item
	weapon_tier = tier
	is_owned = owned
	_border_color = WeaponData.TIER_COLORS.get(tier, Color(0.3, 0.3, 0.3))

	# Icon
	_icon_rect.color = _border_color

	# Type label
	var tier_suffix: String = ""
	if tier != WeaponData.Tier.COMMON:
		tier_suffix = " T%s" % WeaponData.TIER_NAMES[tier]
	_type_label.text = item.name + tier_suffix
	_type_label.add_theme_color_override("font_color", _border_color)

	# Description — BBCode
	var w: WeaponData = _create_weapon_for_preview(item.id, tier)
	_desc_label.text = ""
	if w:
		_desc_label.text = _get_weapon_bbcode(w)
	else:
		_desc_label.text = item.get("description", "")

	# Buy button
	var tier_cost_mult: float = WeaponData.TIER_MULTIPLIERS.get(tier, 1.0)
	var final_cost: int = int(item.cost * tier_cost_mult)
	if owned:
		_buy_button.text = "POSIADANY"
		_buy_button.disabled = true
	else:
		_buy_button.text = "$%d" % final_cost
		_buy_button.disabled = gold < final_cost

	# Banish for weapons
	_banish_button.visible = can_banish and not owned
	_apply_style()


func setup_passive(item: PassiveItem, count: int, synergy_lvl: int, slots_full: bool, gold: int, can_banish: bool) -> void:
	card_type = CardType.PASSIVE
	card_data = item
	_border_color = item.icon_color

	# Icon
	_icon_rect.color = item.icon_color

	# Type label
	_type_label.text = item.item_name
	_type_label.add_theme_color_override("font_color", item.icon_color)

	# Description — BBCode
	_desc_label.text = _get_passive_bbcode(item, count, synergy_lvl)

	# Buy button
	_buy_button.text = "$%d" % item.cost
	_buy_button.disabled = gold < item.cost or slots_full

	# Banish
	_banish_button.visible = can_banish
	_apply_style()


func setup_consumable(item: Dictionary, gold: int) -> void:
	card_type = CardType.CONSUMABLE
	card_data = item
	_border_color = Color(0.2, 0.7, 0.3)

	# Icon
	_icon_rect.color = _border_color

	# Type label
	_type_label.text = item.name

	# Description
	_desc_label.text = "[color=green]%s[/color]" % item.description

	# Buy button
	_buy_button.text = "$%d" % item.cost
	_buy_button.disabled = gold < item.cost

	# No banish
	_banish_button.visible = false
	_apply_style()


func setup_recruit(rc: Dictionary, cost: int, gold: int) -> void:
	card_type = CardType.RECRUIT
	card_data = rc
	_border_color = Color(0.3, 0.6, 1.0)

	_icon_rect.color = _border_color

	_type_label.text = rc.name
	_type_label.add_theme_color_override("font_color", _border_color)

	_desc_label.text = "[color=cyan]%s[/color]" % rc.description

	_buy_button.text = "$%d" % cost
	_buy_button.disabled = gold < cost

	_banish_button.visible = false
	_apply_style()


func set_locked(locked: bool) -> void:
	is_locked = locked
	_lock_button.text = "🔒" if is_locked else "🔓"
	_apply_style()


# ── BBCode Helpers ──

func _get_weapon_bbcode(w: WeaponData) -> String:
	var lines: PackedStringArray = []
	lines.append("[color=green]DMG: %d[/color]" % w.damage)
	lines.append("Ogień: %.1f/s" % w.fire_rate)
	lines.append("Zasięg: %.0f" % w.attack_range)
	if w.projectile_count > 1:
		lines.append("[color=cyan]×%d pocisków[/color]" % w.projectile_count)
	if w.spread_angle > 0.01:
		lines.append("Rozrzut: %.2f" % w.spread_angle)
	return "\n".join(lines)


func _get_passive_bbcode(item: PassiveItem, count: int, synergy_lvl: int) -> String:
	var lines: PackedStringArray = []
	lines.append("[color=green]%s[/color]" % item.description)
	if item.synergy_tag != PassiveItem.SynergyTag.NONE:
		var tag_name: String = ""
		match item.synergy_tag:
			PassiveItem.SynergyTag.SPEED: tag_name = "Szybkość"
			PassiveItem.SynergyTag.DEFENSE: tag_name = "Obrona"
			PassiveItem.SynergyTag.OFFENSE: tag_name = "Ofensywa"
		var syn_color: String = "green" if synergy_lvl >= 2 else "gray"
		lines.append("[color=%s][%s %d/3][/color]" % [syn_color, tag_name, synergy_lvl])
	if count > 0:
		lines.append("[color=yellow]Posiadasz: ×%d[/color]" % count)
	return "\n".join(lines)


func _create_weapon_for_preview(weapon_id: String, tier: WeaponData.Tier) -> WeaponData:
	var weapon_type: WeaponData.Type
	match weapon_id:
		"weapon_rifle": weapon_type = WeaponData.Type.RIFLE
		"weapon_shotgun": weapon_type = WeaponData.Type.SHOTGUN
		"weapon_pistol": weapon_type = WeaponData.Type.PISTOL
		"weapon_smg": weapon_type = WeaponData.Type.SMG
		"weapon_sniper": weapon_type = WeaponData.Type.SNIPER_RIFLE
		"weapon_melee": weapon_type = WeaponData.Type.MELEE
		"weapon_grenade": weapon_type = WeaponData.Type.GRENADE
		_: return null
	return WeaponData.create_tiered(weapon_type, tier)


# ── Signals ──

func _on_buy_pressed() -> void:
	purchased.emit(self)


func _on_lock_pressed() -> void:
	set_locked(!is_locked)
	locked_toggled.emit(self)


func _on_banish_pressed() -> void:
	banished.emit(self)
