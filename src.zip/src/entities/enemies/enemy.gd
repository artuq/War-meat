## Enemy — bazowy wróg z wariantami (Brotato-style)
class_name Enemy
extends CharacterBody2D

enum EnemyType { GRUNT, RUSHER, TANK, SHOOTER, GRENADIER }

@export var max_hp: int = 30
@export var move_speed: float = 40.0
@export var attack_damage: int = 5
@export var gold_value: int = 10
@export var contact_cooldown: float = 0.5
@export var enemy_type: EnemyType = EnemyType.GRUNT

var hp: int
var target: Node2D = null
var _contact_timer: float = 0.0
var xp_value: int = 10

# Knockback state
var _knockback_velocity: Vector2 = Vector2.ZERO
var _knockback_timer: float = 0.0
const KNOCKBACK_FORCE: float = 120.0
const KNOCKBACK_DURATION: float = 0.2

# Attack wind-up state
var _attack_state: int = 0  # 0=chase, 1=windup, 2=cooldown
var _attack_timer: float = 0.0
const ATTACK_RANGE: float = 14.0
const WINDUP_TIME: float = 0.15
const ATTACK_PAUSE: float = 0.4

# Shooter variables
var _shoot_range: float = 120.0
var _shoot_cooldown_max: float = 1.2
var _shoot_cooldown: float = 0.0

# Grenadier variables
var _grenade_range: float = 100.0
var _grenade_cooldown_max: float = 2.5
var _grenade_cooldown: float = 0.0

var _enemy_projectile_scene: PackedScene = preload("res://src/entities/enemies/enemy_projectile.tscn")

# Sprite textures per type (null = use _draw() fallback)
var _sprite_textures: Dictionary = {
	EnemyType.GRUNT: preload("res://assets/sprites/enemies/Grunt.png"),
	EnemyType.RUSHER: preload("res://assets/sprites/enemies/Rusher.png"),
	EnemyType.TANK: preload("res://assets/sprites/enemies/Tank.png"),
	EnemyType.SHOOTER: preload("res://assets/sprites/enemies/Shooter.png"),
	EnemyType.GRENADIER: preload("res://assets/sprites/enemies/Grenadier.png"),
}
var _shadow_texture: Texture2D = preload("res://assets/sprites/soldiers/Shadow.png")
var _has_sprite: bool = false

const VISUAL_SCALE := 0.5

@onready var body_sprite: Sprite2D = $BodySprite
@onready var shadow_sprite: Sprite2D = $Shadow
@onready var collision_shape: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	hp = max_hp
	add_to_group("enemies")
	_apply_visual()


func _draw() -> void:
	# Skip _draw() primitives if this type has a real sprite
	if _has_sprite:
		return
	var radius := 5.0
	var color := Color(0.9, 0.2, 0.2)  # red grunt
	match enemy_type:
		EnemyType.GRUNT:
			radius = 5.0
			color = Color(0.9, 0.2, 0.2)
		EnemyType.RUSHER:
			radius = 4.0
			color = Color(1.0, 0.6, 0.3)
		EnemyType.TANK:
			radius = 7.0
			color = Color(0.6, 0.3, 0.8)
		EnemyType.SHOOTER:
			radius = 5.0
			color = Color(0.2, 0.6, 0.9)
		EnemyType.GRENADIER:
			radius = 6.0
			color = Color(0.9, 0.8, 0.2)
	draw_circle(Vector2.ZERO, radius, color)
	draw_arc(Vector2.ZERO, radius + 1.5, 0, TAU, 32, Color.WHITE, 1.0)
	draw_arc(Vector2.ZERO, radius, 0, TAU, 32, color.darkened(0.3), 1.0)
	# Shooter crosshair indicator
	if enemy_type == EnemyType.SHOOTER:
		draw_line(Vector2(-3, 0), Vector2(3, 0), Color.WHITE, 1.0)
		draw_line(Vector2(0, -3), Vector2(0, 3), Color.WHITE, 1.0)
	# Grenadier warning ring
	if enemy_type == EnemyType.GRENADIER:
		draw_arc(Vector2.ZERO, 8.0, 0, TAU, 16, Color(1, 0.4, 0.1, 0.4), 1.0)


## Konfiguruj wariant wroga — wywoływane PRZED add_child
func configure(type: EnemyType, wave: int) -> void:
	enemy_type = type
	var wave_mult := 1.0 + (wave - 1) * 0.15  # +15% stats per wave
	match type:
		EnemyType.GRUNT:
			max_hp = int(12 * wave_mult)
			move_speed = 40.0 + wave * 2.0
			attack_damage = int(5 * wave_mult)
			gold_value = 10 + wave * 2
			xp_value = 8
		EnemyType.RUSHER:
			max_hp = int(8 * wave_mult)
			move_speed = 75.0 + wave * 3.0
			attack_damage = int(3 * wave_mult)
			gold_value = 8 + wave * 2
			contact_cooldown = 0.3
			xp_value = 8
		EnemyType.TANK:
			max_hp = int(80 * wave_mult)
			move_speed = 20.0 + wave * 1.0
			attack_damage = int(10 * wave_mult)
			gold_value = 30 + wave * 5
			xp_value = 25
		EnemyType.SHOOTER:
			max_hp = int(20 * wave_mult)
			move_speed = 25.0 + wave * 1.0
			attack_damage = int(6 * wave_mult)
			gold_value = 18 + wave * 3
			xp_value = 15
			_shoot_range = 120.0 + wave * 5.0
			_shoot_cooldown_max = 1.2
		EnemyType.GRENADIER:
			max_hp = int(35 * wave_mult)
			move_speed = 22.0 + wave * 1.0
			attack_damage = int(12 * wave_mult)
			gold_value = 25 + wave * 4
			xp_value = 20
			_grenade_range = 100.0 + wave * 5.0
			_grenade_cooldown_max = 2.5


func _apply_visual() -> void:
	# Load sprite texture if available for this type
	if _sprite_textures.has(enemy_type):
		var tex: Texture2D = _sprite_textures[enemy_type]
		body_sprite.texture = tex
		body_sprite.scale = Vector2(VISUAL_SCALE, VISUAL_SCALE)
		body_sprite.visible = true
		_has_sprite = true
		# Precise shadow asset
		shadow_sprite.texture = _shadow_texture
		shadow_sprite.scale = Vector2(VISUAL_SCALE, VISUAL_SCALE)
		shadow_sprite.visible = true
	else:
		body_sprite.visible = false
		shadow_sprite.visible = false

	match enemy_type:
		EnemyType.RUSHER:
			var shape: CircleShape2D = collision_shape.shape
			shape.radius = 4.0
		EnemyType.TANK:
			var shape: CircleShape2D = collision_shape.shape
			shape.radius = 7.0
		EnemyType.GRENADIER:
			var shape: CircleShape2D = collision_shape.shape
			shape.radius = 6.0
	queue_redraw()


func _physics_process(delta: float) -> void:
	# Handle knockback (overrides all other movement)
	if _knockback_timer > 0.0:
		_knockback_timer -= delta
		velocity = _knockback_velocity
		move_and_slide()
		_knockback_velocity *= 0.85  # friction
		return

	_find_target()
	if not is_instance_valid(target):
		return

	# Sprite direction + movement wobble
	if _has_sprite:
		body_sprite.flip_h = target.global_position.x < global_position.x
		if velocity.length() > 5.0:
			body_sprite.rotation = sin(Time.get_ticks_msec() * 0.01) * 0.08
		else:
			body_sprite.rotation = lerpf(body_sprite.rotation, 0.0, 10.0 * delta)

	var dist_to_target := global_position.distance_to(target.global_position)
	var direction := (target.global_position - global_position).normalized()
	var separation := _get_separation_force()

	match enemy_type:
		EnemyType.SHOOTER:
			_shoot_cooldown -= delta
			if dist_to_target > _shoot_range:
				velocity = direction * move_speed + separation
				move_and_slide()
			else:
				velocity = separation
				move_and_slide()
				if _shoot_cooldown <= 0.0:
					_shoot_at_target(direction)
					_shoot_cooldown = _shoot_cooldown_max
		EnemyType.GRENADIER:
			_grenade_cooldown -= delta
			if dist_to_target > _grenade_range * 0.8:
				velocity = direction * move_speed + separation
				move_and_slide()
			else:
				velocity = direction * move_speed * 0.3 + separation
				move_and_slide()
			if dist_to_target < _grenade_range and _grenade_cooldown <= 0.0:
				_throw_grenade(target.global_position)
				_grenade_cooldown = _grenade_cooldown_max
		_:
			# Melee enemies: chase → wind-up → hit → cooldown → chase
			_melee_behavior(delta, direction, separation, dist_to_target)


## Soft-collision separation — pushes enemies apart so they don't stack
func _get_separation_force() -> Vector2:
	const SEPARATION_RADIUS := 14.0
	const SEPARATION_STRENGTH := 55.0
	var force := Vector2.ZERO
	var neighbors := get_tree().get_nodes_in_group("enemies")
	for other in neighbors:
		if other == self or not is_instance_valid(other):
			continue
		var diff: Vector2 = global_position - other.global_position
		var dist: float = diff.length()
		if dist < SEPARATION_RADIUS and dist > 0.01:
			force += diff.normalized() * (SEPARATION_RADIUS - dist) / SEPARATION_RADIUS * SEPARATION_STRENGTH
	return force


func take_damage(amount: int) -> void:
	hp -= amount
	_spawn_damage_number(amount)
	_flash_hit()
	if hp <= 0:
		hp = 0
		_die()


func _flash_hit() -> void:
	modulate = Color(1.0, 1.0, 0.2)  # yellow flash — distinct from player's red
	var tween := create_tween()
	tween.tween_property(self, "modulate", Color.WHITE, 0.15)
	# Scale punch for extra feedback
	if _has_sprite and body_sprite:
		var original_scale: Vector2 = body_sprite.scale
		body_sprite.scale = original_scale * 1.3
		var punch_tween := create_tween()
		punch_tween.tween_property(body_sprite, "scale", original_scale, 0.12).set_ease(Tween.EASE_OUT)


func _spawn_damage_number(amount: int) -> void:
	if not SettingsManager.damage_numbers_enabled:
		return
	var dn := preload("res://src/systems/damage_number.gd").new()
	dn.value = amount
	dn.global_position = global_position + Vector2(0, -8)
	get_tree().current_scene.add_child(dn)


func _die() -> void:
	var death_fx := ParticleFactory.create_death_puff(global_position)
	get_tree().current_scene.add_child(death_fx)
	EventBus.enemy_killed.emit(self, global_position)
	EventBus.enemy_killed_at.emit(global_position)
	EventBus.loot_dropped.emit(global_position, gold_value)
	GameManager.add_xp(xp_value)
	queue_free()


func _find_target() -> void:
	if is_instance_valid(target):
		return
	var squad_members := get_tree().get_nodes_in_group("squad")
	var closest_dist := INF
	for member in squad_members:
		var dist := global_position.distance_to(member.global_position)
		if dist < closest_dist:
			closest_dist = dist
			target = member


## Melee AI: chase → wind-up → hit + knockback → cooldown → chase
func _melee_behavior(delta: float, direction: Vector2, separation: Vector2, dist: float) -> void:
	match _attack_state:
		0:  # CHASE
			velocity = direction * move_speed + separation
			move_and_slide()
			if dist < ATTACK_RANGE:
				_attack_state = 1
				_attack_timer = WINDUP_TIME
				velocity = Vector2.ZERO
		1:  # WIND-UP (stop, prepare to strike)
			velocity = separation * 0.3
			move_and_slide()
			_attack_timer -= delta
			if _attack_timer <= 0.0:
				_do_contact_attack()
				_attack_state = 2
				_attack_timer = ATTACK_PAUSE
		2:  # COOLDOWN (wait before chasing again)
			velocity = separation * 0.5
			move_and_slide()
			_attack_timer -= delta
			if _attack_timer <= 0.0:
				_attack_state = 0


func _do_contact_attack() -> void:
	if not is_instance_valid(target):
		return
	var dist := global_position.distance_to(target.global_position)
	if dist < ATTACK_RANGE + 6.0 and target is Soldier:
		target.take_damage(attack_damage)
		# Knockback self away from target
		var kb_dir := (global_position - target.global_position).normalized()
		_knockback_velocity = kb_dir * KNOCKBACK_FORCE
		_knockback_timer = KNOCKBACK_DURATION


func _apply_knockback(dir: Vector2, force: float) -> void:
	_knockback_velocity = dir * force
	_knockback_timer = KNOCKBACK_DURATION


func _shoot_at_target(direction: Vector2) -> void:
	var proj: EnemyProjectile = _enemy_projectile_scene.instantiate()
	proj.damage = attack_damage
	proj.direction = direction
	proj.global_position = global_position + direction * 8.0
	get_tree().current_scene.add_child(proj)


func _throw_grenade(target_pos: Vector2) -> void:
	var grenade := _EnemyGrenade.new()
	grenade.damage = attack_damage
	grenade.target_pos = target_pos
	grenade.global_position = global_position
	get_tree().current_scene.add_child(grenade)


## Grenade inner class — flies to target, shows warning, explodes
class _EnemyGrenade extends Area2D:
	var damage: int = 12
	var target_pos: Vector2 = Vector2.ZERO
	var _speed: float = 150.0
	var _explode_radius: float = 40.0
	var _arrived: bool = false
	var _fuse_time: float = 0.5
	var _fuse_timer: float = 0.0

	func _ready() -> void:
		collision_layer = 0
		collision_mask = 0
		var timer := get_tree().create_timer(3.0)
		timer.timeout.connect(queue_free)

	func _draw() -> void:
		if _arrived:
			# Warning circle (pulsing red)
			var alpha: float = 0.3 + 0.4 * sin(_fuse_timer * 12.0)
			draw_circle(Vector2.ZERO, _explode_radius, Color(1, 0.2, 0.1, alpha))
			draw_arc(Vector2.ZERO, _explode_radius, 0, TAU, 24, Color(1, 0.3, 0.1, 0.8), 1.5)
		else:
			draw_circle(Vector2.ZERO, 3.0, Color(0.9, 0.8, 0.2))

	func _physics_process(delta: float) -> void:
		if not _arrived:
			var dist := global_position.distance_to(target_pos)
			if dist < 5.0:
				_arrived = true
				global_position = target_pos
				queue_redraw()
			else:
				var dir := (target_pos - global_position).normalized()
				global_position += dir * _speed * delta
		else:
			_fuse_timer += delta
			queue_redraw()
			if _fuse_timer >= _fuse_time:
				_explode()

	func _explode() -> void:
		for s in get_tree().get_nodes_in_group("squad"):
			if is_instance_valid(s) and s is Soldier:
				if global_position.distance_to(s.global_position) < _explode_radius:
					s.take_damage(damage)
		queue_free()
