## SoundManager — globalny system audio (muzyka + SFX pooling)
extends Node

# --- Music players ---
var _music_player: AudioStreamPlayer = null
var _music_intense: AudioStreamPlayer = null
var _current_music_path: String = ""
var _current_intense_path: String = ""

# --- SFX pool ---
const SFX_POOL_SIZE: int = 16
var _sfx_pool: Array[AudioStreamPlayer2D] = []
var _sfx_pool_idx: int = 0

# --- Non-positional SFX ---
const SFX_GLOBAL_POOL_SIZE: int = 4
var _sfx_global_pool: Array[AudioStreamPlayer] = []
var _sfx_global_idx: int = 0

# --- Weapon SFX variants ---
var _weapon_variants: Dictionary = {
	"rifle": [
		preload("res://assets/audio/sfx/weapons/rifle_01.wav"),
		preload("res://assets/audio/sfx/weapons/rifle_02.wav"),
		preload("res://assets/audio/sfx/weapons/rifle_03.wav"),
	],
}

# --- Music tracks ---
var _music_tracks: Dictionary = {
	"menu": preload("res://assets/audio/music/menu/menu_theme.mp3"),
	"hub": preload("res://assets/audio/music/hub_theme.mp3"),
	"jungle_base": preload("res://assets/audio/music/arena_jungle/jungle_base.mp3"),
	"jungle_intense": preload("res://assets/audio/music/arena_jungle/jungle_intense.mp3"),
	"victory": preload("res://assets/audio/music/victory_stinger.mp3"),
}

# Voice limiting per category
var _voice_counts: Dictionary = {}
const MAX_VOICES: Dictionary = {
	"weapon": 3,
	"impact": 8,
}

# Per-category cooldown to prevent same-frame phasing
var _category_cooldowns: Dictionary = {}
const CATEGORY_COOLDOWN_MS: Dictionary = {
	"weapon": 40,  # minimum 40ms between weapon SFX
}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	# Music players
	_music_player = AudioStreamPlayer.new()
	_music_player.bus = "Music"
	_music_player.volume_db = -6.0
	add_child(_music_player)

	_music_intense = AudioStreamPlayer.new()
	_music_intense.bus = "Music"
	_music_intense.volume_db = -40.0  # starts silent
	add_child(_music_intense)

	# SFX 2D pool (positional)
	for i in SFX_POOL_SIZE:
		var player := AudioStreamPlayer2D.new()
		player.bus = "SFX"
		player.max_distance = 500.0
		add_child(player)
		_sfx_pool.append(player)

	# SFX global pool (non-positional)
	for i in SFX_GLOBAL_POOL_SIZE:
		var player := AudioStreamPlayer.new()
		player.bus = "SFX"
		add_child(player)
		_sfx_global_pool.append(player)


# --- MUSIC ---

func play_music(track_name: String, fade_in: float = 1.0) -> void:
	if track_name == _current_music_path:
		return
	_current_music_path = track_name
	_current_intense_path = ""

	if not _music_tracks.has(track_name):
		stop_music()
		return

	var stream: AudioStream = _music_tracks[track_name]
	if _music_player.playing:
		var tween := create_tween()
		tween.tween_property(_music_player, "volume_db", -40.0, 0.5)
		tween.tween_callback(func():
			_music_player.stream = stream
			_music_player.volume_db = -40.0
			_music_player.play()
			var fade := create_tween()
			fade.tween_property(_music_player, "volume_db", -6.0, fade_in)
		)
	else:
		_music_player.stream = stream
		_music_player.volume_db = -40.0
		_music_player.play()
		var tween := create_tween()
		tween.tween_property(_music_player, "volume_db", -6.0, fade_in)

	# Stop intense layer
	_music_intense.stop()
	_music_intense.volume_db = -40.0


func play_music_layered(base_name: String, intense_name: String, fade_in: float = 1.0) -> void:
	_current_music_path = base_name
	_current_intense_path = intense_name

	if _music_tracks.has(base_name):
		_music_player.stream = _music_tracks[base_name]
		_music_player.volume_db = -40.0
		_music_player.play()
		var tween := create_tween()
		tween.tween_property(_music_player, "volume_db", -6.0, fade_in)

	if _music_tracks.has(intense_name):
		_music_intense.stream = _music_tracks[intense_name]
		_music_intense.volume_db = -40.0
		_music_intense.play()


func set_music_intensity(intensity: float) -> void:
	if _current_intense_path == "":
		return
	# Base volume: -6 at 0 intensity → -20 at 1.0
	_music_player.volume_db = lerpf(-6.0, -20.0, intensity)
	# Intense volume: -40 at 0 intensity → -6 at 1.0
	_music_intense.volume_db = lerpf(-40.0, -6.0, intensity)


func stop_music(fade_out: float = 0.5) -> void:
	_current_music_path = ""
	_current_intense_path = ""
	if _music_player.playing:
		var tween := create_tween()
		tween.tween_property(_music_player, "volume_db", -40.0, fade_out)
		tween.tween_callback(_music_player.stop)
	if _music_intense.playing:
		var tween2 := create_tween()
		tween2.tween_property(_music_intense, "volume_db", -40.0, fade_out)
		tween2.tween_callback(_music_intense.stop)


func play_stinger(track_name: String) -> void:
	if not _music_tracks.has(track_name):
		return
	var player := _get_global_player()
	player.stream = _music_tracks[track_name]
	player.volume_db = -3.0
	player.pitch_scale = 1.0
	player.play()


# --- SFX ---

func play_weapon_sfx(weapon_type: String, pos: Vector2, pitch_variance: float = 0.15) -> void:
	if not _weapon_variants.has(weapon_type):
		return
	# Voice limiting
	var count: int = _voice_counts.get("weapon", 0)
	if count >= MAX_VOICES.get("weapon", 3):
		return
	# Per-category cooldown — prevent same-frame phasing
	var now_ms: int = Time.get_ticks_msec()
	var last_ms: int = _category_cooldowns.get("weapon", 0)
	var cd: int = CATEGORY_COOLDOWN_MS.get("weapon", 40)
	if now_ms - last_ms < cd:
		return
	_category_cooldowns["weapon"] = now_ms
	_voice_counts["weapon"] = count + 1

	var variants: Array = _weapon_variants[weapon_type]
	var stream: AudioStream = variants[randi() % variants.size()]
	var player := _get_pooled_player()
	player.stream = stream
	player.pitch_scale = randf_range(1.0 - pitch_variance, 1.0 + pitch_variance)
	player.global_position = pos
	player.volume_db = -8.0
	player.play()
	player.finished.connect(func(): _voice_counts["weapon"] = maxi(_voice_counts.get("weapon", 1) - 1, 0), CONNECT_ONE_SHOT)


func play_sfx_2d(stream: AudioStream, pos: Vector2, volume_db: float = 0.0, pitch_variance: float = 0.05) -> void:
	var player := _get_pooled_player()
	player.stream = stream
	player.pitch_scale = randf_range(1.0 - pitch_variance, 1.0 + pitch_variance)
	player.global_position = pos
	player.volume_db = volume_db
	player.play()


# --- WAVE TRANSITIONS ---

## Duck music & clear SFX pool when entering shop
func duck_for_shop(fade_time: float = 0.5) -> void:
	# Immediately mute SFX bus to kill any in-flight sounds (hit, death, etc.)
	var sfx_bus := AudioServer.get_bus_index("SFX")
	if sfx_bus >= 0:
		AudioServer.set_bus_mute(sfx_bus, true)
	# Stop all pooled players
	for player in _sfx_pool:
		if player.playing:
			player.stop()
	for player in _sfx_global_pool:
		if player.playing:
			player.stop()
	_voice_counts.clear()
	# Duck music bus to -20 dB
	var bus_idx := AudioServer.get_bus_index("Music")
	if bus_idx >= 0:
		var tween := create_tween()
		tween.tween_method(func(db: float): AudioServer.set_bus_volume_db(bus_idx, db),
			AudioServer.get_bus_volume_db(bus_idx), -20.0, fade_time)


## Restore music bus when returning to arena
func resume_from_shop(fade_time: float = 0.8) -> void:
	# Restore SFX bus to user settings
	var sfx_bus := AudioServer.get_bus_index("SFX")
	if sfx_bus >= 0:
		if SettingsManager.sfx_volume > 0.01:
			AudioServer.set_bus_mute(sfx_bus, false)
			AudioServer.set_bus_volume_db(sfx_bus, linear_to_db(SettingsManager.sfx_volume))
	# Fade music bus back to user's preferred volume
	var bus_idx := AudioServer.get_bus_index("Music")
	if bus_idx >= 0:
		var target_db: float = linear_to_db(maxf(SettingsManager.music_volume, 0.02))
		var tween := create_tween()
		tween.tween_method(func(db: float): AudioServer.set_bus_volume_db(bus_idx, db),
			AudioServer.get_bus_volume_db(bus_idx), target_db, fade_time)


# --- POOL ---

func _get_pooled_player() -> AudioStreamPlayer2D:
	var player := _sfx_pool[_sfx_pool_idx]
	_sfx_pool_idx = (_sfx_pool_idx + 1) % SFX_POOL_SIZE
	if player.playing:
		player.stop()
	return player


func _get_global_player() -> AudioStreamPlayer:
	var player := _sfx_global_pool[_sfx_global_idx]
	_sfx_global_idx = (_sfx_global_idx + 1) % SFX_GLOBAL_POOL_SIZE
	if player.playing:
		player.stop()
	return player
